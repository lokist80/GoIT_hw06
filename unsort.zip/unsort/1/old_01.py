import pygame
import random
from time import sleep

pygame.init()

screen = width, height = 800, 600
BACKGROUND = 0, 0, 0

main_surface = pygame.display.set_mode(size=screen)

is_working = True


def change_color():
    ball_color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    return ball_color


ball = pygame.Surface((20, 20))
ball.fill(color=change_color())
ball_rect = ball.get_rect()
ball_speed = [1, 1]

while is_working:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_working = False

    if ball_rect.bottom > height or ball_rect.top < 0:
        ball_speed[1] = -ball_speed[1]
        ball.fill(color=change_color())
    if ball_rect.left < 0 or ball_rect.right > width:
        ball_speed[0] = -ball_speed[0]
        ball.fill(color=change_color())

    sleep(0.002)

    ball_rect = ball_rect.move(ball_speed)
    main_surface.fill(color=BACKGROUND)
    main_surface.blit(ball, ball_rect)
    pygame.display.flip()
